from django.shortcuts import render



# Create your views here.
def home(request):
    return render (request,"home.html")

def about (request):
    return render (request,"about.html")

def projects (request):
    projects_show=[
        {
            'title': 'Food cart',
            'path': 'images/rasoi_connect.PNG',
        },
        {
            'title': 'Spotify clone',
            'path': 'images/spotify-clone.png',
        },

        {
            'title': 'Photo Uploader',
            'path': 'images/photo_uploader.PNG',
        },
          

    ]
    return render (request,"projects.html",{"projects_show": projects_show})

def experience(request):
    experience=[
        {"company":"Meta Scifor Technology",
         "position":"python developer intern"},
        {"company":"Veritech Software services pvt. ltd.",
         "position":"Web Development intern"},
         {"company":"Chegg india pvt. ltd.",
         "position":"Computer science subject expert"},
        
    ]
    return render (request,"experience.html",{"experience":experience})

def certificate(request):
    return render (request, "certificate.html")

def contact(request):
    return render (request,"contact.html")




    
